Boolean
//true -> verdadeiro
//false <- falso
const PrimeiroNumero=5;
const SegundoNumero=5;
let CadastroAtivado=true;

console.log (PrimeiroNumero === SegundoNumero);//igual
console.log (PrimeiroNumero != SegundoNumero);//diferente
console.log (PrimeiroNumero < SegundoNumero);//menor
console.log (PrimeiroNumero > SegundoNumero);//maior
console.log (PrimeiroNumero <= SegundoNumero);//menor ou igual
console.log (PrimeiroNumero >= SegundoNumero);//maior ou igual

const texto1="Alura";
const texto2="Alura";

console.log(texto1 === texto2)