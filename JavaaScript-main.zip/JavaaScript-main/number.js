//tipo number

const MeuNumero=3;

const PrimeiroNumero=1;
const SegundoNumero=2;
const TerceiroNumero=2.1;

let soma=PrimeiroNumero+SegundoNumero;
let subtracao=PrimeiroNumero-SegundoNumero;
let multiplicacao=PrimeiroNumero*SegundoNumero;
let divisao=PrimeiroNumero/SegundoNumero;

console.log("A soma é",soma);
console.log("A subtração é",subtracao);
console.log("A multiplicação é",multiplicacao);
console.log("A divisão é",divisao,"\n")