//Tipo String

const texto1="Olá munddo!"
const texto2='Olá mundo!'
const senha="senha@Supersegura456"
const StringDeNumeros="34567",

cont citacao="Meu nome é";
const meu nome="Ariélly";

//Concatação (+)

console.log (texto1)
console.log (texto2)
console.log (senha)
console.log (StringDeNumeros)
console.log (citacao+meuNome)

//Template string ou template literal