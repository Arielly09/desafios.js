//Boolean
//true -> verdadeiro
//false <- falso
const PrimeiroNumero=5
const SegundoNumero=5