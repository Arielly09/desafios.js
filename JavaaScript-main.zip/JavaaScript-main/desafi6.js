const salaJS = ["Evaldo", "Camis", "Mari"];
const salaPython = ["Ju", "Leo", "Raquel"];

const SalasUnificadas = salaJS.concat(salaPython);
const SalasUnificadas2 = salaPython.concat(salaJS);

console.log(SalasUnificadas)
console.log(SalasUnificadas2)