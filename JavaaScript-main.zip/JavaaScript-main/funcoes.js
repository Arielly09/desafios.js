function imprimirTexto (texto){
    console.log(texto);
}

imprimirTexto("Olá")

function texto(text){
    return text;
}
console.log(texto("parametro"));

function soma(numero1,numero2){
    return numero1+numero2;
}

function subtracao(numero1,numero2){
    return numero1-numero2;
}
function multiplicacao(numero1,numero2){
    return numero1*numero2;
}
function divisao(numero1,numero2){
    return numero1/numero2;
}
console.log ("A soma dos números é", soma);
console.log("A subtração dos números é",subtracao);
console.log("A multiplicação dos números é",subtracao);
console.log("A divisão dos números é",divisao);

